package com.amazon.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.amazon.pages.CartPage;
import com.amazon.pages.HomePage;
import com.amazon.pages.PaymentPage;
import com.amazon.pages.ProductPage;
import com.amazon.pages.ShippingAddressPage;
import com.amazon.utils.Common;
import com.amazon.utils.DataUtils;

public class TestExecutor {

	public static WebDriver driver;
	public static String userDir = System.getProperty("user.dir");
	public static DesiredCapabilities cap = null;

	public static ExtentTest logger;
	public static DataUtils dataUtils;
	public static Properties prop = new Properties();
	public static Common common;

	public static HomePage homePage = new HomePage();
	public static ProductPage productPage = new ProductPage();
	public static CartPage cartPage = new CartPage();
	public static ShippingAddressPage addressPage = new ShippingAddressPage();
	public static PaymentPage paymentPage = new PaymentPage();

	public Map<String, String> map = new HashMap<String, String>();
	public DataFormatter formatter = new DataFormatter();
	public FileInputStream File;
	public XSSFWorkbook book;
	public XSSFSheet sheet;

	static ExtentReports report;
	FileInputStream fis = null;

	@BeforeClass(enabled = true)
	public static ExtentReports launch() {
		String destFile = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-ss");
		destFile = userDir + "\\test-output\\extentreports\\ecom";
		String destDir = dateFormat.format(new Date()) + ".html";
		report = new ExtentReports(destFile + "\\" + destDir, true);
		report.loadConfig(new File(userDir + "\\src\\test\\java\\com\\lol\\config\\reports.xml"));
		return report;
	}

	@AfterClass(enabled = false)
	public void result() {
		driver.close();
	}

	@AfterSuite(enabled = true)
	public void teartown() {
		driver.close();
	}

	@BeforeMethod(enabled = true)
	public void startTest(Method method) throws IOException {
		initialize();

		driver.get(prop.getProperty("URL"));
		System.out.println("Successfully Openedapplication ");
		driver.manage().window().maximize();
	}

	@BeforeSuite(enabled = true)
	public void start() {
		// driver.close();
	}

	@AfterMethod(enabled = false)
	public void reportclosewindows() throws IOException, InterruptedException {
		report.endTest(logger);
		report.flush();
	}

	public static void loadPropertiesFile() throws IOException {
		FileInputStream fn = null;
		fn = new FileInputStream(userDir + "\\src\\test\\java\\com\\amazon\\config\\config.properties");
		prop.load(fn);
	}

	@Parameters("browser")
	public static void initialize() throws IOException {

		if (driver == null) {

			loadPropertiesFile();

			if (prop.getProperty("browser", "chrome").equals("chrome")) {
				System.out.println(prop.getProperty("browser"));
				System.setProperty("webdriver.chrome.driver", userDir + "\\exe\\chromedriver.exe");
				cap = DesiredCapabilities.chrome();
				cap.setBrowserName("chrome");
				driver = new ChromeDriver(cap);
				cap.setPlatform(Platform.ANY);
			}
		}

		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);

		common = new Common();
		dataUtils = new DataUtils();

	}

	public String getData(String columnName) {
		return dataUtils.getMapValue(columnName);
	}

}
