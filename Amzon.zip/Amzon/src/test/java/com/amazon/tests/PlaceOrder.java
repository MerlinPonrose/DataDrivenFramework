package com.amazon.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.amazon.pages.CartPage;
import com.relevantcodes.extentreports.LogStatus;

public class PlaceOrder extends TestExecutor {

	@Test(enabled = true)
	public void orderProduct() throws IOException, InterruptedException {

		try {
			dataUtils.setSheetName("PlaceOrder");
			int i = 1;
			while (i <= dataUtils.noOfRows()) {
				// while (i <= 4) {
				dataUtils.getRowData(i);
				if (getData("RunThis").toLowerCase().equals("yes")) {
					System.out.println(i);

					String scenario = getData("Scenario Description");
					logger = report.startTest(scenario);
					logger.log(LogStatus.INFO, "=======Start Execution Report========");

					// Maximize window
					common.maximizeWindow();

					// Click SignIn
					common.click(homePage.signIn, "User clicks on SignIn");
					homePage.login();

					// ClearCart
					cartPage.clearCart();

					// Enter product in searchbox
					homePage.enterProduct();

					// Get the Product price
					productPage.getPriceValue();

					// Select the product
					productPage.clickProduct();

					// Verify Right product is selected
					productPage.verifySelectedProduct();

					// Click Add To Cart
					cartPage.clickAddToCartInAnotherWindow();

					// Click Mini cart
					cartPage.clickMiniCart();

					// Click Proceed To Buy
					cartPage.clickProceedToBuy();

					// Select Shipping Address
					addressPage.selectShippingAddress();

					// Click Continue
					paymentPage.clickContinue();

					// Select Payment Method
					paymentPage.clickCashOnDelivery();

					// Click Continue
					paymentPage.clickContinueButton();

					// Verify Product Detail
					paymentPage.verifyProductDetail();

					// Verify Price Detail
					paymentPage.validateProductPrice();

					// Return to Amazon Home Page
					paymentPage.clickReturnToHomePage();

					// ClearCart
					cartPage.clearCart();

					// verify empty cart
					cartPage.verifyEmptyCart();

					logger.log(LogStatus.INFO, "=======End Execution Report======");
					reportclosewindows();
				} else {
					System.out.println("Skipped scenario : " + getData("Scenario Description"));
				}

				i++;
			}
		} catch (Exception e) {

			common.captureSS("Errors found", LogStatus.FAIL);
			reportclosewindows();
			System.out.println("Exception occured during execution: " + e.getMessage());
			Assert.assertTrue(false);
		}
	}
}
