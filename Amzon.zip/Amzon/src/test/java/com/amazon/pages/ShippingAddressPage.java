package com.amazon.pages;

import org.openqa.selenium.By;

import com.amazon.tests.TestExecutor;

public class ShippingAddressPage extends TestExecutor {

	public By shippingAddress = By
			.xpath("//b[text()='MerlinNative']//..//..//..//..//..//.//a[contains(text(),'Deliver to this address')]");
	

	public void selectShippingAddress() {
		common.jsScrolltillelementview(shippingAddress);
		common.click(shippingAddress, "User selects the shipping Address");
	}

}
