package com.amazon.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.amazon.tests.TestExecutor;

public class HomePage extends TestExecutor{


	
	
	public By signIn = By.xpath("//a[@id='nav-link-accountList']");
	public By email = By.xpath("//input[@name='email']");
	public By searchTextBox = By.xpath("//input[@id='twotabsearchtextbox']");
	public By submitButton = By.xpath("//input[@type='submit']");
	public By password = By.xpath("//input[@id='ap_password']");
	
	
	
	




	public void login()
	{
		common.click(email,"User clicks on Email");
		common.type(email, getData("Phone Number"));
		common.click(submitButton,"User clicks on Submit Button");
		
		common.click(password,"User clicks on password");
		common.type(password, getData("Password"));
		common.click(submitButton,"User clicks on Submit Button");
	}
	
	public void enterProduct()
	{
		common.click(homePage.searchTextBox, "User clicks on Search text box");
		common.type(homePage.searchTextBox, getData("Product Name"));
		common.click(homePage.submitButton, "User clicks on submit button");
	}
}
