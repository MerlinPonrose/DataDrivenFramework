package com.amazon.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.amazon.tests.TestExecutor;
import com.relevantcodes.extentreports.LogStatus;

public class CartPage extends TestExecutor {

	public By miniCart = By.xpath("//span[@class='nav-cart-icon nav-sprite']");
	public By delete = By.xpath("//input[@value='Delete']");
	public By addToCart = By.xpath("//input[@title='Add to Shopping Cart']");
	public By proceedToBuy = By.xpath("//input[@value='Proceed to checkout']");
	public By emptyCart = By.xpath("//h1[contains(text(),'Your Shopping Cart is empty')]");

	public void clickMiniCart() {
		common.clickUsingJavaScript(By.xpath("//span[@class='nav-cart-icon nav-sprite']"));
	}

	public void clearCart() {
		clickMiniCart();
		int size = driver.findElements(delete).size();
		if (size == 0) {
			System.out.println("Empty cart");
		} else {
			for (int i = 1; i <= size; i++) {
				common.click(By.xpath("(//input[@value='Delete'])[" + i + "]"), "User click on delete button");
			}
		}

	}

	public void clickAddToCart() {
		common.click(addToCart, "User clicks on Add to Cart");
	}

	public void clickAddToCartInAnotherWindow() {
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> itr = windows.iterator();

		String parentWindow = itr.next();

		String childWindow = itr.next();

		driver.switchTo().window(childWindow);
		clickAddToCart();
		driver.close();
		driver.switchTo().window(parentWindow);
	}

	public void clickProceedToBuy() {
		common.click(proceedToBuy, "User clicks on Proceed to Buy");
	}

	public void verifyEmptyCart() {
		if (driver.findElements(emptyCart).size() != 0) {
			logger.log(LogStatus.PASS, "Cart is empty");
		} else {
			logger.log(LogStatus.FAIL, "Cart is not empty");
		}
	}
}
