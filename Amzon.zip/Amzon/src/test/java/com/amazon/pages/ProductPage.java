package com.amazon.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.amazon.tests.TestExecutor;
import com.relevantcodes.extentreports.LogStatus;

public class ProductPage extends TestExecutor {

	public By price = By.xpath("//span[@id='priceblock_ourprice']");
	public String productPrice;

	public void clickProduct() {
		common.jsScrolltillelementview(By.xpath("//span[text()='" + getData("Product Name") + "']"));
		common.clickUsingJavaScript(By.xpath("//span[text()='" + getData("Product Name") + "']"));
	}

	public void verifySelectedProduct()

	{
		String prodName = getData("Product Name");
		if (driver.findElements(By.xpath("//span[contains(text(),'" + prodName + "')]")).size() != 0) {
			System.out.println("Displayed product is same as selected");
		} else {
			System.out.println("Displayed product is not same as selected");
		}

	}

	public void getPriceValue() {
		common.waitExplicitlyForPresence(By.xpath(
				"//span[text()='" + getData("Product Name") + "']//..//..//..//..//span[@class='a-price-whole']"), 30);
		productPrice = driver.findElement(By.xpath(
				"//span[text()='" + getData("Product Name") + "']//..//..//..//..//span[@class='a-price-whole']"))
				.getText();
		System.out.println("Product Price =" + productPrice);
		logger.log(LogStatus.INFO, "Product Price =" + productPrice);
	}
}
