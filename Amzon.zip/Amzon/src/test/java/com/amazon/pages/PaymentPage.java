package com.amazon.pages;

import org.openqa.selenium.By;

import com.amazon.tests.TestExecutor;
import com.relevantcodes.extentreports.LogStatus;

public class PaymentPage extends TestExecutor {

	public By cashOnDelivery = By.xpath("//span[text()='Pay on Delivery (Cash)']");
	public By continueButton = By.xpath("(//input[@value='Continue'])[1]");
	public By continueInOrderPage = By.xpath("(//span[text()='Continue'])[1]");
	public By returnToHomePage = By.xpath("//a[text()='Amazon.in homepage']");
	public By totalPrice = By.xpath("(//span[contains(@style,'text-decoration')])[2]");

	public void clickCashOnDelivery() {
		common.click(cashOnDelivery, "User clicks on Cash On Delivery");
	}

	public void clickContinue() {
		common.click(continueButton, "User clicks on continue Button");
	}

	public void clickContinueButton() {
		common.clickUsingJavaScript(continueInOrderPage);
	}

	public void clickReturnToHomePage() {
		common.jsScrolltillelementview(returnToHomePage);
		common.click(returnToHomePage, "User clicks on return to home link");
	}

	public void verifyProductDetail() {
		String prodName = getData("Product Name");
		common.waitExplicitlyForPresence(By.xpath("//strong[text()='" + prodName + "']"), 30);
		int size = driver.findElements(By.xpath("//strong[text()='" + prodName + "']")).size();
		if (size != 0) {
			logger.log(LogStatus.PASS, "Added Product is displayed in Place order page");
			System.out.println("Added Product is displayed in Place order page");
		} else {
			logger.log(LogStatus.FAIL, "Added Product is displayed in Place order page");
			System.out.println("Added Product is displayed in Place order page");
		}

	}

	public void validateProductPrice() {
		common.waitExplicitlyForPresence(totalPrice, 30);
		String finalPrice = driver.findElement(totalPrice).getText();
		String[] split = finalPrice.split("[.]");
		System.out.println("Total Price=" + split[0]);
		logger.log(LogStatus.INFO, "Total Price=" + split[0]);

		if (split[0].contains(productPage.productPrice)) {
			logger.log(LogStatus.PASS, "Product Price is same as total price");
			System.out.println("Product Price is same as total price");
		} else {
			logger.log(LogStatus.PASS, "Product price is not same as total price");
			System.out.println("Product price is not same as total price");
		}
	}
}
