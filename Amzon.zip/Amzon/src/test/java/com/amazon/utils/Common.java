package com.amazon.utils;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.TestException;

import com.amazon.tests.TestExecutor;
import com.amazon.listener.ExtentReportNG;
import com.relevantcodes.extentreports.LogStatus;

public class Common extends TestExecutor {

	public String screenshot = "C:\\AutomationProject\\Screenshot";

	public void maximizeWindow() {
		driver.manage().window().maximize();
	}

	public void click(By locator, String msg) {
		try {
			waitExplicitlyForPresence(locator, 30);
			driver.findElement(locator).click();
			logger.log(LogStatus.PASS, msg);
		} catch (AssertionError e) {
			logger.log(LogStatus.FAIL, msg + " is not displayed");
			String Screenshotpath = ExtentReportNG.captureScreenshot(msg);
			String image = logger.addScreenCapture(Screenshotpath);
			logger.log(LogStatus.FAIL, image);
		}

	}

	public void type(By locator, String msg) {
		waitExplicitlyForPresence(locator, 20);
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(msg);

	}

	public void waitExplicitlyForPresence(By locator, int timeToWait) {

		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public void jsScrolltillelementview(By locator) {
		waitExplicitlyForPresence(locator, 30);
		WebElement element = driver.findElement(locator);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void clickUsingJavaScript(By locator) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(locator);
		executor.executeScript("arguments[0].click();", element);
	}

	public String CaptureScreenShot(WebDriver driver, String fileName) {
		TakesScreenshot efwd = ((TakesScreenshot) driver);
		File src = efwd.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File("./ScreenShotLib/" + fileName));
		} catch (Exception e) {

		}
		return screenshot + fileName + ".jpg";
	}

	public void captureSS(String titleImg, LogStatus status) {
		String Screenshotpath = ExtentReportNG.captureScreenshot(titleImg);
		String image = logger.addScreenCapture(Screenshotpath);
		logger.log(status, image);
	}

}
